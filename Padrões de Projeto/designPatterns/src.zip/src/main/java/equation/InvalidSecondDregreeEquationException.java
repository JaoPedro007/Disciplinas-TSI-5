package equation;

@SuppressWarnings("serial")
public class InvalidSecondDregreeEquationException extends RuntimeException{
	
	 
	public InvalidSecondDregreeEquationException(String message) {
		super(message);
	}
}
